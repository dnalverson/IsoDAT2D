# IsoDAT2D
 A tool for analyzing thin film total scattering measurments with non-negative matric factorization and hierarchical agglomerative clustering.